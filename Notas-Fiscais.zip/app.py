

import os
import json
import re
import base64
import traceback
from datetime import datetime

from flask import Flask, request, jsonify, render_template
from werkzeug.utils import secure_filename

import google.generativeai as genai
from google.generativeai.types import HarmCategory, HarmBlockThreshold

# --------------------------------------------------------------------------
# CONFIGURAÇÃO
# --------------------------------------------------------------------------

APP_ROOT = os.path.dirname(os.path.abspath(__file__))
UPLOAD_FOLDER = os.path.join(APP_ROOT, "uploads_tmp")
ALLOWED_EXTENSIONS = {"pdf"}
MAX_CONTENT_LENGTH = 15 * 1024 * 1024  # 15 MB

os.makedirs(UPLOAD_FOLDER, exist_ok=True)

app = Flask(__name__)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["MAX_CONTENT_LENGTH"] = MAX_CONTENT_LENGTH

GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY")
GEMINI_MODEL_NAME = os.environ.get("GEMINI_MODEL", "gemini-flash-lite-latest")

if GEMINI_API_KEY:
    genai.configure(api_key=GEMINI_API_KEY)

# --------------------------------------------------------------------------
# REGRAS DE NEGÓCIO — CATEGORIAS DE DESPESA VÁLIDAS
# (usadas tanto no prompt quanto na validação da resposta do Gemini)
# --------------------------------------------------------------------------

CATEGORIAS_DESPESA = {
    "INSUMOS AGRÍCOLAS": [
        "Sementes", "Fertilizantes", "Defensivos Agrícolas", "Corretivos"
    ],
    "MANUTENÇÃO E OPERAÇÃO": [
        "Combustíveis e Lubrificantes", "Peças", "Parafusos",
        "Componentes Mecânicos", "Manutenção de Máquinas e Equipamentos",
        "Pneus", "Filtros", "Correias", "Ferramentas e Utensílios"
    ],
    "RECURSOS HUMANOS": [
        "Mão de Obra Temporária", "Salários e Encargos"
    ],
    "SERVIÇOS OPERACIONAIS": [
        "Frete e Transporte", "Colheita Terceirizada",
        "Secagem e Armazenagem", "Pulverização e Aplicação"
    ],
    "INFRAESTRUTURA E UTILIDADES": [
        "Energia Elétrica", "Arrendamento de Terras",
        "Construções e Reformas", "Materiais de Construção"
    ],
    "ADMINISTRATIVAS": [
        "Honorários (Contábeis, Advocatícios, Agronômicos)",
        "Despesas Bancárias e Financeiras"
    ],
    "SEGUROS E PROTEÇÃO": [
        "Seguro Agrícola", "Seguro de Ativos", "Seguro Prestamista"
    ],
    "IMPOSTOS E TAXAS": [
        "ITR", "IPTU", "IPVA", "INCRA-CCIR"
    ],
    "INVESTIMENTOS": [
        "Aquisição de Máquinas e Implementos", "Aquisição de Veículos",
        "Aquisição de Imóveis", "Infraestrutura Rural"
    ],
}

CATEGORIAS_PRINCIPAIS = list(CATEGORIAS_DESPESA.keys())

# --------------------------------------------------------------------------
# PROMPT INTERNO ENVIADO AO GEMINI
# --------------------------------------------------------------------------

def montar_prompt_extracao() -> str:
    """
    Monta o prompt textual enviado junto com o PDF para o Gemini.
    Define explicitamente a estrutura JSON de saída (com arrays de
    parcelas e categorias de despesa) e a lista de categorias válidas
    para classificação, conforme as regras de negócio do projeto.
    """

    lista_categorias_formatada = "\n".join(
        f"- {categoria_principal}: {', '.join(subitens)}"
        for categoria_principal, subitens in CATEGORIAS_DESPESA.items()
    )

    prompt = f"""
Você é um assistente especializado em extração de dados de Notas Fiscais /
Faturas brasileiras em PDF, para uso em um sistema administrativo-financeiro
do agronegócio.

Analise o documento PDF fornecido e extraia EXATAMENTE os dados abaixo,
devolvendo a resposta em um ÚNICO objeto JSON válido, SEM nenhum texto
antes ou depois, SEM markdown, SEM blocos de código (não use ```).

ESTRUTURA JSON OBRIGATÓRIA (siga rigorosamente os nomes de campos e tipos):

{{
  "fornecedor": {{
    "razao_social": string ou null,
    "nome_fantasia": string ou null,
    "cnpj": string ou null
  }},
  "faturado": {{
    "nome_completo": string ou null,
    "cpf": string ou null
  }},
  "nota_fiscal": {{
    "numero": string ou null,
    "data_emissao": string ou null (formato DD/MM/AAAA)
  }},
  "descricao_produtos": string ou null,
  "valor_total": number ou null,
  "quantidade_parcelas": integer,
  "parcelas": [
    {{
      "numero_parcela": integer,
      "data_vencimento": string (formato DD/MM/AAAA),
      "valor_parcela": number
    }}
  ],
  "classificacao_despesas": [
    {{
      "categoria_principal": string (uma das CATEGORIAS PRINCIPAIS abaixo),
      "subcategoria": string (um dos subitens listados dentro da categoria escolhida),
      "justificativa": string (breve explicação de por que essa classificação foi escolhida com base na descrição dos produtos)
    }}
  ],
  "observacoes": string ou null (use para alertar sobre dados não encontrados ou ambíguos)
}}

REGRAS IMPORTANTES:

1. "parcelas" é SEMPRE um array, mesmo que exista apenas 1 parcela. Se a nota
   não indicar parcelamento explícito, considere 1 parcela única, usando a
   data de vencimento encontrada (ou a data de emissão + observação no campo
   "observacoes" caso nenhuma data de vencimento seja identificada).

2. "classificacao_despesas" é SEMPRE um array e PODE conter MAIS DE UM item,
   pois uma mesma nota pode conter produtos/serviços de categorias
   diferentes. Classifique com base na "descricao_produtos", interpretando o
   conteúdo — a nota fiscal NÃO traz a categoria diretamente, você deve
   INFERIR a partir dos itens descritos.

3. Utilize OBRIGATORIAMENTE apenas as categorias principais e subcategorias
   listadas abaixo. Nunca invente uma categoria fora desta lista. Se não
   for possível classificar com confiança, use categoria_principal
   "ADMINISTRATIVAS" e subcategoria mais próxima, explicando a incerteza em
   "justificativa".

CATEGORIAS PRINCIPAIS E SUBCATEGORIAS VÁLIDAS:
{lista_categorias_formatada}

4. Valores monetários ("valor_total", "valor_parcela") devem ser números
   (float), usando ponto como separador decimal, SEM símbolo de moeda e SEM
   separador de milhar (exemplo correto: 1234.56).

5. Se um campo não for encontrado no documento, utilize null (não invente
   dados, não deixe strings vazias "").

6. CNPJ e CPF devem ser devolvidos apenas com os números e pontuação como
   aparecem no documento (não remova nem reformate).

7. A resposta final deve ser SOMENTE o objeto JSON, sem comentários, sem
   markdown, sem ```json, começando em {{ e terminando em }}.

Agora analise o PDF anexado e gere o JSON.
""".strip()

    return prompt


# --------------------------------------------------------------------------
# UTILITÁRIOS
# --------------------------------------------------------------------------

def allowed_file(filename: str) -> bool:
    return (
            "." in filename
            and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS
    )


def limpar_mensagem_de_erro(mensagem: str) -> str:
    """
    Remove qualquer chave de API que apareça na mensagem de erro.

    Os SDKs do Google incluem a chave na URL da requisição
    (ex.: ...?key=AIzaSy...), o que exporia o segredo na tela do
    navegador. Toda mensagem devolvida ao frontend passa por aqui.
    """
    if not mensagem:
        return ""

    # Remove o parâmetro key=<valor> em URLs
    mensagem = re.sub(r"(key=)[^\s&\"'\\]+", r"\1***REMOVIDA***", mensagem)

    # Remove qualquer chave no formato AIza... ou AQ.Ab8... que tenha sobrado
    mensagem = re.sub(r"\bAIza[0-9A-Za-z\-_]{10,}", "***REMOVIDA***", mensagem)
    mensagem = re.sub(r"\bAQ\.[0-9A-Za-z\-_\.]{10,}", "***REMOVIDA***", mensagem)

    return mensagem


def traduzir_erro_gemini(erro: Exception) -> tuple:
    """
    Traduz o erro técnico da API do Gemini em uma mensagem clara em
    português. Retorna (mensagem, status_http).
    """
    texto = limpar_mensagem_de_erro(str(erro))

    if "API_KEY_INVALID" in texto or "API key not valid" in texto:
        return (
            "A chave da API do Gemini foi rejeitada. Verifique se a "
            "GEMINI_API_KEY está correta e se pertence ao mesmo projeto "
            "em que a API Gemini está habilitada.",
            502,
        )

    if "PERMISSION_DENIED" in texto or "has not been used in project" in texto:
        return (
            "A API Gemini não está habilitada no projeto desta chave, ou a "
            "chave não tem permissão para usá-la. Habilite a API no Google "
            "Cloud Console (APIs e Serviços > Biblioteca).",
            502,
        )

    if "RESOURCE_EXHAUSTED" in texto or "quota" in texto.lower():
        return (
            "Limite de uso da API do Gemini atingido (cota do plano "
            "gratuito). Aguarde alguns minutos e tente novamente — o "
            "limite por minuto se renova automaticamente. Se persistir "
            "por horas, é a cota diária: use outra chave/projeto ou "
            "aguarde a renovação.",
            429,
        )

    if "NOT_FOUND" in texto or "is not found for API version" in texto:
        return (
            f"O modelo '{GEMINI_MODEL_NAME}' não está disponível para esta "
            "chave. Defina a variável GEMINI_MODEL com um modelo válido "
            "(por exemplo: gemini-1.5-flash).",
            502,
        )

    if "DEADLINE_EXCEEDED" in texto or "timeout" in texto.lower():
        return (
            "A análise do PDF demorou mais que o limite da API. Tente "
            "novamente ou use um arquivo menor.",
            504,
        )

    return (f"Não foi possível concluir a extração: {texto}", 500)


def extrair_json_da_resposta(texto_resposta: str) -> dict:
    """
    Tenta converter a resposta de texto do Gemini em um dict Python.
    Faz limpeza defensiva caso o modelo devolva markdown (```json ... ```)
    ou texto extra antes/depois do JSON.
    """
    if not texto_resposta:
        raise ValueError("Resposta vazia do modelo Gemini.")

    texto = texto_resposta.strip()

    # Remove blocos de código markdown, se existirem
    texto = re.sub(r"^```(?:json)?\s*", "", texto, flags=re.IGNORECASE)
    texto = re.sub(r"\s*```$", "", texto)
    texto = texto.strip()

    # Tenta o parse direto primeiro
    try:
        return json.loads(texto)
    except json.JSONDecodeError:
        pass

    # Fallback: extrai o primeiro bloco { ... } mais externo encontrado
    inicio = texto.find("{")
    fim = texto.rfind("}")
    if inicio == -1 or fim == -1 or fim <= inicio:
        raise ValueError(
            "Não foi possível localizar um objeto JSON na resposta do modelo."
        )

    trecho_json = texto[inicio : fim + 1]
    return json.loads(trecho_json)


def validar_estrutura_dados(dados: dict) -> list:
    """
    Valida a presença e o formato mínimo dos campos esperados.
    Retorna uma lista de avisos (strings). Não levanta exceção — os avisos
    são devolvidos ao frontend junto com os dados, para transparência.
    """
    avisos = []

    campos_topo_esperados = [
        "fornecedor", "faturado", "nota_fiscal", "descricao_produtos",
        "valor_total", "quantidade_parcelas", "parcelas",
        "classificacao_despesas",
    ]
    for campo in campos_topo_esperados:
        if campo not in dados:
            avisos.append(f"Campo obrigatório ausente na resposta: '{campo}'.")

    # Parcelas deve ser lista
    parcelas = dados.get("parcelas")
    if parcelas is not None and not isinstance(parcelas, list):
        avisos.append("'parcelas' deveria ser uma lista (array), mas não é.")
    elif isinstance(parcelas, list):
        for i, parcela in enumerate(parcelas):
            if "data_vencimento" not in parcela:
                avisos.append(f"Parcela {i + 1} sem 'data_vencimento'.")
            if "valor_parcela" not in parcela:
                avisos.append(f"Parcela {i + 1} sem 'valor_parcela'.")

    # Classificação de despesas deve ser lista e usar categorias válidas
    classificacoes = dados.get("classificacao_despesas")
    if classificacoes is not None and not isinstance(classificacoes, list):
        avisos.append(
            "'classificacao_despesas' deveria ser uma lista (array), mas não é."
        )
    elif isinstance(classificacoes, list):
        if len(classificacoes) == 0:
            avisos.append("Nenhuma categoria de despesa foi identificada.")
        for i, item in enumerate(classificacoes):
            categoria = item.get("categoria_principal")
            if categoria not in CATEGORIAS_PRINCIPAIS:
                avisos.append(
                    f"Classificação {i + 1}: categoria_principal "
                    f"'{categoria}' não está na lista de categorias válidas."
                )

    return avisos


# --------------------------------------------------------------------------
# ROTAS
# --------------------------------------------------------------------------

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/extrair-dados", methods=["POST"])
def extrair_dados():
    """
    Recebe o PDF via multipart/form-data (campo 'arquivo'), envia para o
    Gemini junto com o prompt de extração, valida a estrutura devolvida
    e retorna o JSON final para o frontend.
    """

    if not GEMINI_API_KEY:
        return jsonify({
            "sucesso": False,
            "erro": (
                "GEMINI_API_KEY não configurada no servidor. Defina a "
                "variável de ambiente antes de iniciar a aplicação."
            ),
        }), 500

    if "arquivo" not in request.files:
        return jsonify({
            "sucesso": False,
            "erro": "Nenhum arquivo foi enviado (campo 'arquivo' ausente).",
        }), 400

    arquivo = request.files["arquivo"]

    if arquivo.filename == "":
        return jsonify({
            "sucesso": False,
            "erro": "Nenhum arquivo selecionado.",
        }), 400

    if not allowed_file(arquivo.filename):
        return jsonify({
            "sucesso": False,
            "erro": "Formato inválido. Apenas arquivos PDF são aceitos.",
        }), 400

    nome_seguro = secure_filename(arquivo.filename)
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S%f")
    caminho_temp = os.path.join(
        app.config["UPLOAD_FOLDER"], f"{timestamp}_{nome_seguro}"
    )

    try:
        arquivo.save(caminho_temp)

        # 1) Lê o PDF e converte para base64.
        #
        # O envio é feito "inline", com o PDF anexado à própria chamada de
        # geração. Isso evita a etapa separada de upload de arquivo, que
        # exige outro tipo de credencial e falha com chaves restritas a
        # conta de serviço.
        with open(caminho_temp, "rb") as f:
            bytes_pdf = f.read()

        documento_pdf = {
            "mime_type": "application/pdf",
            "data": base64.b64encode(bytes_pdf).decode("utf-8"),
        }

        # 2) Monta o modelo e o prompt
        modelo = genai.GenerativeModel(
            model_name=GEMINI_MODEL_NAME,
            generation_config={
                "temperature": 0.1,
                "response_mime_type": "application/json",
            },
            safety_settings={
                HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT: HarmBlockThreshold.BLOCK_NONE,
            },
        )

        prompt_extracao = montar_prompt_extracao()

        # 3) Envia PDF (inline) + prompt para o Gemini
        resposta = modelo.generate_content([documento_pdf, prompt_extracao])

        texto_resposta = getattr(resposta, "text", None)

        if not texto_resposta:
            return jsonify({
                "sucesso": False,
                "erro": (
                    "O modelo Gemini não retornou conteúdo de texto. "
                    "O PDF pode estar ilegível, corrompido ou bloqueado "
                    "por filtros de segurança."
                ),
            }), 502

        # 4) Faz o parse defensivo do JSON
        try:
            dados_extraidos = extrair_json_da_resposta(texto_resposta)
        except (ValueError, json.JSONDecodeError) as erro_parse:
            return jsonify({
                "sucesso": False,
                "erro": (
                    "Não foi possível interpretar a resposta do Gemini "
                    "como JSON válido: "
                    f"{limpar_mensagem_de_erro(str(erro_parse))}"
                ),
                "resposta_bruta": limpar_mensagem_de_erro(texto_resposta),
            }), 502

        # 5) Validação estrutural (não bloqueante — apenas avisos)
        avisos = validar_estrutura_dados(dados_extraidos)

        # 6) Limpeza do arquivo remoto no Gemini (boa prática)
        try:
            genai.delete_file(arquivo_gemini.name)
        except Exception:
            pass  # limpeza best-effort, não deve falhar a requisição

        return jsonify({
            "sucesso": True,
            "dados": dados_extraidos,
            "avisos": avisos,
        }), 200

    except Exception as erro:
        traceback.print_exc()
        mensagem_erro, status_erro = traduzir_erro_gemini(erro)
        return jsonify({
            "sucesso": False,
            "erro": mensagem_erro,
        }), status_erro

    finally:
        # Remove o arquivo temporário local, se ainda existir
        if os.path.exists(caminho_temp):
            try:
                os.remove(caminho_temp)
            except OSError:
                pass


@app.errorhandler(413)
def arquivo_grande_demais(_erro):
    return jsonify({
        "sucesso": False,
        "erro": "Arquivo muito grande. O limite é de 15 MB.",
    }), 413


if __name__ == "__main__":
    app.run(debug=True, host="127.0.0.1", port=5000)
